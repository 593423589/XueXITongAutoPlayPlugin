/*
 *  打开浏览器控制台，鼠标右键点击检查（谷歌、QQ浏览器是这样）
 *  复制下面代码，粘贴到控制台上，回车。
 */


let title = document.querySelector('#mainid>h1')

let videoBox = []

let videoIndex = 0

let videoMute = false
let videoRate = false

function playVideos(i) {
    if (i >= videoBox.length ) nextPage()

    if (videoBox[i]) {
        let {video} = videoBox[i]
        video.play()
        muteCtrler()
        rateCtrler()
        function videoCancelPause(){
            video.play()
        }
        video.addEventListener('pause',videoCancelPause)
        video.addEventListener('ended', () => {
            video.removeEventListener('pause',videoCancelPause)
            playVideos(++videoIndex)
        })
    }
}

function playAllVideos() {
    let videosSum = 0
    for (let i =0;i< videoBox.length;i++) {
        let {video} = videoBox[i]
        video.play()
        muteCtrler()
        rateCtrler()

        video.addEventListener('pause', () => {
            video.play()
        })
        video.addEventListener('ended', () => {
            videosSum++
            if(videosSum > videoBox.length){
                nextPage()
            }
        })
    }
}

function muteCtrl() {
    videoMute = true
    muteCtrler()
}

function muteCtrler() {
    if(videoMute){
        for (let i =0;i< videoBox.length;i++) {
            let {volume} = videoBox[i]
            volume.click()
        }
    }
}

function rateCtrl() {
    videoRate = true
    rateCtrler()
}
function rateCtrler() {
    if(videoRate){
        for (let i =0;i< videoBox.length;i++) {
            let {rate} = videoBox[i]
            rate.click()
        }
    }
}


function alert(text, timeout = 10000) {
    let div = document.createElement('div')
    div.innerHTML = text
    div.setAttribute('style', 'position:fixed; left:0vw; top:0vh; ;height: 20vh; width:30vw;text-align:center; background:#0006;color:#fff;font-size:20px')
    document.body.appendChild(div)
    setTimeout(() => {
        div.style.display = 'none'
    }, timeout)
}

async function autoPlay() {
    alert(`正在自动播放>>>`, 2000)

    let iframes = null
    await new Promise(resolve => {
        let getIframes = setInterval(()=>{
            try {
                iframes = document.querySelector('iframe').contentWindow.document.querySelectorAll('iframe')
            }catch (e) {}
            if(iframes){
                getIframes = null
                clearInterval(getIframes)
                resolve()
            }
        },100)

    })
    await new Promise(resolve => {
        setTimeout(() => {
            for (let i of iframes) {
                let conWindow = i.contentWindow.document
                let video = conWindow.querySelector('video')
                let rate = conWindow.querySelector('.vjs-playback-rate')
                let volume = conWindow.querySelector('.vjs-volume-panel')
                if (video && rate && volume) {
                    videoBox.push({
                        video,
                        rate: rate.firstElementChild,
                        volume:volume.firstElementChild
                    })
                }
            }
            resolve()
        }, 1500)
    })
    playVideos(videoIndex)

}

function nextPage() {
    videoIndex = 0   //从第一个视频开始
    videoBox = []
    document.querySelector('.orientationright').click()
    let tryTimes = 0
    window.interval = setInterval(() => {
        let newTitle = document.querySelector('#mainid>h1')
        if (newTitle && newTitle !== title) {
            let iframeReady = document.querySelector('iframe').contentWindow.document.querySelectorAll('iframe').length
            if (iframeReady || tryTimes > 5) {
                title = newTitle
                window.clearInterval(window.interval)
                window.interval = null
                autoPlay()
            }

        }
        tryTimes++
    }, 100)
}


function init() {
    alert(`正在自动播放，请在网络质量好的环境使用，默认播放速度1.25倍。</br>自动播放过程中，如跳转到其他视频后请点击按钮手动开始。`)

    let appConsole = document.createElement('div')
    appConsole.setAttribute('style',
        'position:fixed;z-index:1000;left:30vw; top:0vh;height: 15vh; width:20vw;text-align:center; background:#fff;border:1px solid #000;')
    let p = document.createElement('p')
    p.append('学习通自动播放中')

    let button1 = document.createElement('button')
    button1.append('手动开始')
    button1.setAttribute('style', 'font-size:17px;margin-top: 3vh;')
    button1.addEventListener('click', ()=>{
        videoIndex = 0
        videoBox = []
        autoPlay()
    })

    let button2 = document.createElement('button')
    button2.append('全部播放')
    button2.setAttribute('style', 'font-size:17px;margin-top: 3vh;')
    button2.addEventListener('click', playAllVideos)

    let button3 = document.createElement('button')
    button3.append('静音播放')
    button3.setAttribute('style', 'font-size:17px;margin-top: 3vh;')
    button3.addEventListener('click', muteCtrl)

    let button4 = document.createElement('button')
    button4.append('加速播放')
    button4.setAttribute('style', 'font-size:17px;margin-top: 3vh;')
    button4.addEventListener('click', rateCtrl)

    appConsole.appendChild(p)
    appConsole.appendChild(button1)
    appConsole.appendChild(button2)
    appConsole.appendChild(button3)
    appConsole.appendChild(button4)

    document.body.appendChild(appConsole)
    autoPlay()
    setInterval(()=>{
        let flag = videoBox.length
        for (let i=0;i<videoBox.length;i++){
            let {video} = videoBox[i]
            if(video.paused) flag--
        }
        if(!flag){
            alert('检测到视频暂停，继续自动播放中')
            videoBox = []
            videoIndex = 0
            autoPlay()
        }

    },10000)

}

init()
